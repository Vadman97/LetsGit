public class Body
{
	int	positionX, positionY;

	Body(int posX, int posY)
	{
		positionX = posX;
		positionY = posY;
	}

	int getPosX()
	{
		return positionX;
	}

	int getPosY()
	{
		return positionY;
	}

}
