<?php
header("HTTP/1.1 503 Service Unavailable");
?>
<h1>Dear user, our site is undergoing <b>serious</b> maintainance. We will be back up shortly. Thanks!</h1>