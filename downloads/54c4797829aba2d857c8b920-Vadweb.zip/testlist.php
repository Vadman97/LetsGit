<?php
    require_once("util.php");
    print_r(readFileList());


