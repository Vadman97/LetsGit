<?php
	ini_set('display_errors', 'On');
	error_reporting(E_ALL);
	require_once("util.php");
	makeLink("swag.google.com swag.com lel this is a test.com www.test.com lel.com/swag.php?swag=swag&swag=swag i would like to have this swag swaggered");
	echo thumbnailCached(360)?1:0;
?>
