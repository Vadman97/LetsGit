<?php
	echo "First line!<br>";
	require 'dbcon.php';
	echo "dbcon initialized!<br>";
	
	print_r($_SESSION);
?>